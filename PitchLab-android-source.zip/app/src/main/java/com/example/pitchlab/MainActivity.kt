package com.example.pitchlab

import android.Manifest
import android.app.Activity
import android.bluetooth.*
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.widget.*
import java.text.SimpleDateFormat
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.*
import kotlin.math.roundToInt

/** BLE bullpen logger with a capture-validated PitchLogic speed/spin decoder. */
class MainActivity : Activity() {
 private lateinit var status: TextView
 private lateinit var log: TextView
 private lateinit var devices: LinearLayout
 private lateinit var speed: EditText
 private lateinit var spin: EditText
 private lateinit var pitchType: Spinner
 private lateinit var pitchList: LinearLayout
 private lateinit var pitchCount: TextView
 private val handler = Handler(Looper.getMainLooper())
 private val adapter by lazy { (getSystemService(BLUETOOTH_SERVICE) as BluetoothManager).adapter }
 private val seen = mutableSetOf<String>()
 private val pendingDescriptors: ArrayDeque<BluetoothGattDescriptor> = ArrayDeque()
 private var gatt: BluetoothGatt? = null
 private var scanning = false
 private data class PendingPitch(var speedMph: Double? = null, var spinRpm: Int? = null, var updatedAt: Long = 0)
 private val pendingPitches = mutableMapOf<Int, PendingPitch>()
 private val savedEvents = mutableMapOf<Int, Long>()
 private val pitchLogicDataUuid = UUID.fromString("4b810002-0394-7ff1-f00b-ab59cb8a9de3")
 private val scanCallback = object : ScanCallback() {
  override fun onScanResult(callbackType: Int, result: ScanResult) {
   val device = result.device
   if (!seen.add(device.address)) return
   val name = result.scanRecord?.deviceName ?: if (connectAllowed()) device.name else null
   runOnUiThread {
    devices.addView(Button(this@MainActivity).apply {
     text = "${name ?: "Unknown device"} • ${device.address} • ${result.rssi} dBm"
     setOnClickListener { stopScan(); connect(device) }
    })
   }
  }
  override fun onScanFailed(errorCode: Int) { show("Scan failed: $errorCode") }
 }
 private val callback = object : BluetoothGattCallback() {
  override fun onConnectionStateChange(g: BluetoothGatt, statusCode: Int, state: Int) {
   if (statusCode == BluetoothGatt.GATT_SUCCESS && state == BluetoothProfile.STATE_CONNECTED) {
    show("Ball connected; preparing live pitch stream")
    if (connectAllowed() && !g.requestMtu(247)) g.discoverServices()
   } else {
    show("Disconnected: $statusCode")
    pendingDescriptors.clear()
    g.close()
    if (gatt === g) gatt = null
   }
  }
  override fun onMtuChanged(g: BluetoothGatt, mtu: Int, statusCode: Int) {
   show("Bluetooth packet size: $mtu")
   if (connectAllowed()) g.discoverServices()
  }
  override fun onServicesDiscovered(g: BluetoothGatt, statusCode: Int) {
   if (statusCode != BluetoothGatt.GATT_SUCCESS) { show("Service discovery failed: $statusCode"); return }
   g.services.forEach { service ->
    show("Service ${service.uuid}")
    service.characteristics.forEach { c ->
     show("Characteristic ${c.uuid} properties=0x${c.properties.toString(16)}")
     if (c.properties and (BluetoothGattCharacteristic.PROPERTY_NOTIFY or BluetoothGattCharacteristic.PROPERTY_INDICATE) != 0 && connectAllowed()) {
      g.setCharacteristicNotification(c, true)
      c.getDescriptor(UUID.fromString("00002902-0000-1000-8000-00805f9b34fb"))?.let { pendingDescriptors.add(it) }
     }
    }
   }
   writeNextDescriptor(g)
  }
  override fun onDescriptorWrite(g: BluetoothGatt, d: BluetoothGattDescriptor, statusCode: Int) {
   show("Subscribed ${d.characteristic.uuid}: $statusCode")
   writeNextDescriptor(g)
  }
  override fun onCharacteristicChanged(g: BluetoothGatt, c: BluetoothGattCharacteristic, value: ByteArray) { packet(c.uuid, value) }
  @Deprecated("Android 13 compatibility") override fun onCharacteristicChanged(g: BluetoothGatt, c: BluetoothGattCharacteristic) {
   @Suppress("DEPRECATION") val bytes = c.value ?: byteArrayOf()
   packet(c.uuid, bytes)
  }
 }
 private fun writeNextDescriptor(g: BluetoothGatt) {
  if (!connectAllowed()) return
  val d = pendingDescriptors.poll() ?: return
  val indication = d.characteristic.properties and BluetoothGattCharacteristic.PROPERTY_NOTIFY == 0
  val value = if (indication) BluetoothGattDescriptor.ENABLE_INDICATION_VALUE else BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE
  if (Build.VERSION.SDK_INT >= 33) {
   val code = g.writeDescriptor(d, value)
   if (code != BluetoothStatusCodes.SUCCESS) { show("Subscription request failed: $code"); writeNextDescriptor(g) }
  } else if (!writeLegacyDescriptor(g, d, value)) writeNextDescriptor(g)
 }
 @Suppress("DEPRECATION") private fun writeLegacyDescriptor(g: BluetoothGatt, d: BluetoothGattDescriptor, value: ByteArray): Boolean {
  d.value = value
  return g.writeDescriptor(d)
 }
 private fun packet(uuid: UUID, value: ByteArray) {
  if (Looper.myLooper() != Looper.getMainLooper()) {
   val copy = value.clone()
   handler.post { packet(uuid, copy) }
   return
  }
  show("Notify $uuid: ${value.joinToString("") { "%02X".format(it.toInt() and 255) }}")
  if (uuid == pitchLogicDataUuid) decodePitchLogic(value)
 }
 private fun u8(value: Byte) = value.toInt() and 0xff
 private fun leFloat(value: ByteArray, offset: Int): Float? {
  if (offset < 0 || offset + 4 > value.size) return null
  return ByteBuffer.wrap(value, offset, 4).order(ByteOrder.LITTLE_ENDIAN).float.takeIf { it.isFinite() }
 }
 private fun decodePitchLogic(value: ByteArray) {
  if (value.size < 4) return
  val prefix = u8(value[0])
  val family = u8(value[1])
  val subtype = u8(value[2])
  val event = u8(value[3])
  if (prefix !in setOf(0x9a, 0x9e)) return

  when {
   // Capture-verified summary: 9A-1C-50-event, little-endian float32 at byte 26.
   family == 0x1c && subtype == 0x50 -> {
    val mph = leFloat(value, 26)?.toDouble()
    if (mph != null && mph in 10.0..130.0) {
     val pending = pendingPitches.getOrPut(event) { PendingPitch() }
     pending.speedMph = mph
     pending.updatedAt = System.currentTimeMillis()
     show("Pitch $event decoded: ${"%.2f".format(Locale.US, mph)} mph")
     finishDecodedPitch(event)
    }
   }
   // Capture-verified spin summary: 9A/9E-1B-68-event. Several fields carry
   // filtered/instantaneous RPM; their median is stable and rejects an outlier.
   family == 0x1b && subtype == 0x68 -> {
    val rpmOffsets = intArrayOf(22, 26, 30, 34, 42, 46, 90, 94, 98)
    val candidates = rpmOffsets.mapNotNull { leFloat(value, it)?.toDouble() }
     .filter { it in 300.0..5000.0 }.sorted()
    if (candidates.isNotEmpty()) {
     val middle = candidates.size / 2
     val median = if (candidates.size % 2 == 1) candidates[middle]
      else (candidates[middle - 1] + candidates[middle]) / 2.0
     val pending = pendingPitches.getOrPut(event) { PendingPitch() }
     pending.spinRpm = median.roundToInt()
     pending.updatedAt = System.currentTimeMillis()
     show("Pitch $event decoded: ${pending.spinRpm} rpm")
     finishDecodedPitch(event)
    }
   }
  }
  val cutoff = System.currentTimeMillis() - 120_000
  pendingPitches.entries.removeAll { it.value.updatedAt < cutoff }
 }
 private fun finishDecodedPitch(event: Int) {
  val now = System.currentTimeMillis()
  savedEvents.entries.removeAll { now - it.value > 120_000 }
  if (event in savedEvents) return
  val pitch = pendingPitches[event] ?: return
  val mph = pitch.speedMph ?: return
  val rpm = pitch.spinRpm ?: return
  savedEvents[event] = now
  pendingPitches.remove(event)
  savePitchRecord(pitchType.selectedItem?.toString() ?: "Pitch", mph, rpm, "pitchlogic", event)
 }
 private fun permission(permission: String) = checkSelfPermission(permission) == PackageManager.PERMISSION_GRANTED
 private fun connectAllowed() = Build.VERSION.SDK_INT < 31 || permission(Manifest.permission.BLUETOOTH_CONNECT)
 private fun show(message: String) {
  runOnUiThread {
   status.text = message
   val line = "${SimpleDateFormat("HH:mm:ss.SSS", Locale.US).format(Date())} $message\n"
   log.append(line)
   openFileOutput("ble_trace.txt", MODE_APPEND).use { it.write(line.toByteArray()) }
  }
 }
 override fun onCreate(savedInstanceState: Bundle?) {
  super.onCreate(savedInstanceState)
  window.statusBarColor = android.graphics.Color.rgb(6, 14, 25)
  window.navigationBarColor = android.graphics.Color.rgb(6, 14, 25)
  val bg = android.graphics.Color.rgb(8, 19, 33)
  val accent = android.graphics.Color.rgb(71, 221, 244)
  val muted = android.graphics.Color.rgb(165, 188, 204)
  val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(bg) }
  val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24, 20, 24, 28) }
  root.addView(ScrollView(this).apply { isFillViewport = true; addView(content) })
  content.addView(TextView(this).apply { text = "PITCHLAB"; textColor = accent; textSize = 15f; letterSpacing = .18f })
  content.addView(TextView(this).apply { text = "Bullpen"; textColor = android.graphics.Color.WHITE; textSize = 34f })
  status = TextView(this).apply { text = "Ball disconnected • manual entry ready"; textColor = muted; textSize = 14f; setPadding(0, 8, 0, 8) }; content.addView(status)
  content.addView(Button(this).apply { text = "CONNECT BALL"; setOnClickListener { startScan() } })
  devices = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }; content.addView(devices)
  content.addView(TextView(this).apply { text = "NEW PITCH"; textColor = accent; textSize = 16f; setPadding(0, 22, 0, 10) })
  pitchType = Spinner(this).apply {
   adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item,
    listOf("Fastball", "Four seam", "Two seam", "Sinker", "Cutter", "Slider", "Curveball", "Changeup", "Splitter", "Other"))
  }; content.addView(pitchType)
  speed = EditText(this).apply { hint = "Speed in mph (manual)"; setHintTextColor(muted); setTextColor(android.graphics.Color.WHITE); inputType = 8194 }; content.addView(speed)
  spin = EditText(this).apply { hint = "Spin in rpm (manual)"; setHintTextColor(muted); setTextColor(android.graphics.Color.WHITE); inputType = 8194 }; content.addView(spin)
  content.addView(Button(this).apply { text = "SAVE PITCH"; setOnClickListener { savePitch() } })
  pitchCount = TextView(this).apply { textColor = accent; textSize = 16f; setPadding(0, 20, 0, 10) }; content.addView(pitchCount)
  pitchList = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }; content.addView(pitchList)
  content.addView(Button(this).apply { text = "EXPORT PITCHES"; setOnClickListener { shareCsv() } })
  content.addView(TextView(this).apply { text = "BLUETOOTH DIAGNOSTICS"; textColor = accent; textSize = 16f; setPadding(0, 24, 0, 6) })
  content.addView(Button(this).apply { text = "SHARE CONNECTION TRACE"; setOnClickListener { shareTrace() } })
  log = TextView(this).apply { text = "Ready to scan\n"; textColor = muted; textSize = 11f; setTextIsSelectable(true); maxLines = 8 }
  content.addView(log)
  setContentView(root)
  refreshPitches()
 }
 private fun startScan() {
  val required = if (Build.VERSION.SDK_INT >= 31) arrayOf(Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT) else arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)
  val missing = required.filterNot(::permission)
  if (missing.isNotEmpty()) { requestPermissions(missing.toTypedArray(), 1); return }
  if (adapter?.isEnabled != true) { show("Enable Bluetooth in Android settings"); return }
  stopScan(); devices.removeAllViews(); seen.clear()
  scanning = true; adapter.bluetoothLeScanner.startScan(scanCallback); show("Scanning for 12 seconds")
  handler.postDelayed({ stopScan() }, 12000)
 }
 private fun stopScan() {
  if (scanning && (Build.VERSION.SDK_INT < 31 || permission(Manifest.permission.BLUETOOTH_SCAN))) adapter?.bluetoothLeScanner?.stopScan(scanCallback)
  scanning = false
 }
 private fun connect(device: BluetoothDevice) {
  if (!connectAllowed()) return
  gatt?.close(); pendingDescriptors.clear(); pendingPitches.clear(); savedEvents.clear(); show("Connecting to ${device.address}")
  gatt = device.connectGatt(this, false, callback, BluetoothDevice.TRANSPORT_LE)
 }
 private fun savePitch() {
  val mph = speed.text.toString().toDoubleOrNull(); val rpm = spin.text.toString().toIntOrNull()
  if (mph == null || rpm == null || mph !in 1.0..130.0 || rpm !in 0..6000) { show("Enter speed 1–130 mph and spin 0–6000 rpm"); return }
  savePitchRecord(pitchType.selectedItem.toString(), mph, rpm, "manual", null)
  speed.text.clear(); spin.text.clear()
 }
 private fun savePitchRecord(type: String, mph: Double, rpm: Int, source: String, event: Int?) {
  val time = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS", Locale.US).format(Date())
  getSharedPreferences("pitches", MODE_PRIVATE).edit()
   .putString(time, "$type,${"%.2f".format(Locale.US, mph)},$rpm,$source,${event ?: ""}").apply()
  show(if (source == "pitchlogic") "Auto-saved pitch ${event ?: ""}: ${"%.2f".format(Locale.US, mph)} mph • $rpm rpm" else "Saved $type: ${"%.2f".format(Locale.US, mph)} mph • $rpm rpm")
  refreshPitches()
 }
 private fun entries() = getSharedPreferences("pitches", MODE_PRIVATE).all.entries.sortedBy { it.key }
 private fun refreshPitches() {
  val items = entries().asReversed()
  pitchCount.text = "RECENT PITCHES  •  ${items.size}"
  pitchList.removeAllViews()
  if (items.isEmpty()) {
   pitchList.addView(TextView(this).apply { text = "Save a pitch to see it here. Tap a pitch to open its replay."; textColor = android.graphics.Color.LTGRAY; setPadding(8, 12, 8, 20) })
  }
  items.take(20).forEach { entry ->
   val fields = entry.value.toString().split(",")
   val heading = "${fields.getOrNull(0) ?: "Pitch"}   ${fields.getOrNull(1) ?: "—"} mph   ${fields.getOrNull(2) ?: "—"} rpm"
   pitchList.addView(Button(this).apply {
    text = "$heading\n${entry.key.replace('T', ' ')}  •  WATCH REPLAY"
    isAllCaps = false
    setOnClickListener { startActivity(Intent(this@MainActivity, ReplayActivity::class.java).putExtra("pitch_key", entry.key)) }
   })
  }
 }
 private fun shareCsv() {
  val csv = "timestamp,pitch_type,speed_mph,spin_rpm,source,event_id\n" + entries().joinToString("\n") { entry ->
   val fields = entry.value.toString().split(",")
   "${entry.key},${fields.getOrElse(0) { "Pitch" }},${fields.getOrElse(1) { "" }},${fields.getOrElse(2) { "" }},${fields.getOrElse(3) { "manual" }},${fields.getOrElse(4) { "" }}"
  }
  share("PitchLab pitches", csv)
 }
 private fun shareTrace() {
  val trace = try { openFileInput("ble_trace.txt").bufferedReader().use { it.readText() } } catch (_: Exception) { "No diagnostic data yet." }
  share("PitchLab Bluetooth trace", trace)
 }
 private fun share(title: String, body: String) {
  val intent = Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_SUBJECT, title); putExtra(Intent.EXTRA_TEXT, body) }
  startActivity(Intent.createChooser(intent, "Share $title"))
 }
 override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
  super.onRequestPermissionsResult(requestCode, permissions, grantResults)
  if (requestCode == 1 && grantResults.isNotEmpty() && grantResults.all { it == PackageManager.PERMISSION_GRANTED }) startScan()
  else show("Bluetooth permission required for scanning")
 }
 override fun onDestroy() { stopScan(); if (connectAllowed()) gatt?.close(); super.onDestroy() }
}
