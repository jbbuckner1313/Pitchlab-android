package com.example.pitchlab

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.graphics.Canvas
import android.graphics.Paint
import android.view.MotionEvent
import org.json.JSONObject
import org.json.JSONArray
import android.bluetooth.*
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.bluetooth.le.ScanSettings
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.widget.*
import java.text.SimpleDateFormat
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.*
import kotlin.math.roundToInt

/** BLE ball connection and pitch UI; sensor metric decoding requires validation. */
class MainActivity : Activity() {
 private lateinit var latestSpeed: TextView
 private lateinit var latestSpin: TextView
 private lateinit var latestLabel: TextView
 private lateinit var axisReading: TextView
 private lateinit var directionReading: TextView
 private lateinit var horizontalReading: TextView
 private lateinit var verticalReading: TextView
 private lateinit var detailSource: TextView
 private var selectedPitchKey: String? = null
 private var markingTouch = false
 private var touchPoints = JSONArray()
 private fun pitchDetails(key: String?) = try {
  JSONObject(getSharedPreferences("pitch_details", MODE_PRIVATE).getString(key ?: "", "{}") ?: "{}")
 } catch (_: Exception) { JSONObject() }
 private fun storeDetails(value: JSONObject) {
  val key = selectedPitchKey ?: return
  getSharedPreferences("pitch_details", MODE_PRIVATE).edit().putString(key,value.toString()).apply()
  refreshDetails()
 }
 private fun refreshDetails() {
  val data = pitchDetails(selectedPitchKey)
  axisReading.text = if(data.has("axis")) "${data.getDouble("axis")}°" else "—"
  directionReading.text = data.optString("direction", "—")
  horizontalReading.text = if(data.has("horizontal")) "${data.getDouble("horizontal")} in" else "—"
  verticalReading.text = if(data.has("vertical")) "${data.getDouble("vertical")} in" else "—"
  touchPoints = data.optJSONArray("touch_points") ?: JSONArray()
  detailSource.text = if(data.length() == 0) "Awaiting verified sensor metrics" else "Manual comparison values · touch points are user annotations"
  spinView.invalidate()
 }
 private fun editPitchDetails() {
  val key = selectedPitchKey
  if (key == null) { Toast.makeText(this,"Save a pitch first",Toast.LENGTH_SHORT).show(); return }
  val data = pitchDetails(key)
  val form = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20),dp(8),dp(20),dp(8)) }
  form.addView(label("Manual comparison values",14f))
  val record = getSharedPreferences("pitches",MODE_PRIVATE).getString(key, "") ?: ""
  val fields = record.split(",").toMutableList()
  val types = listOf("Fastball","Four seam","Two seam","Sinker","Cutter","Slider","Curveball","Changeup","Splitter","Other")
  form.addView(label("Pitch identifier (your tag)",12f,muted))
  val type = Spinner(this).apply { adapter=ArrayAdapter(this@MainActivity,android.R.layout.simple_spinner_dropdown_item,types); setSelection(types.indexOf(fields.firstOrNull()).coerceAtLeast(0)) }; form.addView(type)
  fun input(title: String, name: String, numeric: Boolean = true): EditText {
   form.addView(label(title,12f,muted))
   return EditText(this).apply { inputType=if(numeric) 12290 else 1; if(data.has(name)) setText(data.get(name).toString()); form.addView(this) }
  }
  val axis=input("Spin axis (0–360°)","axis")
  val direction=input("Spin direction (clock, e.g. 1:30)","direction",false)
  val horizontal=input("Horizontal movement (inches, signed)","horizontal")
  val vertical=input("Vertical movement (inches, signed)","vertical")
  form.addView(label("Use one consistent movement convention when comparing pitches.",12f,muted))
  val dialog=AlertDialog.Builder(this).setTitle("Pitch details").setView(ScrollView(this).apply { addView(form) }).setNegativeButton("Cancel",null).setPositiveButton("Save",null).create()
  dialog.setOnShowListener {
   dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
    val a=axis.text.toString().trim(); val d=direction.text.toString().trim(); val h=horizontal.text.toString().trim(); val v=vertical.text.toString().trim()
    if((a.isNotEmpty() && (a.toDoubleOrNull()?.let { it.isFinite() && it in 0.0..360.0 } != true)) ||
     (d.isNotEmpty() && !Regex("(?:[1-9]|1[0-2]):[0-5][0-9]").matches(d)) ||
     listOf(h,v).any { it.isNotEmpty() && (it.toDoubleOrNull()?.let { n -> n.isFinite() && n in -100.0..100.0 } != true) }) {
     Toast.makeText(this,"Use axis 0–360, a clock direction such as 1:30, and movement within ±100 inches",Toast.LENGTH_LONG).show(); return@setOnClickListener
    }
    listOf("axis" to a,"horizontal" to h,"vertical" to v).forEach { (k,value) -> if(value.isEmpty()) data.remove(k) else data.put(k,value.toDouble()) }
    if(d.isEmpty()) data.remove("direction") else data.put("direction",d)
    if(fields.isNotEmpty()) fields[0]=type.selectedItem.toString()
    getSharedPreferences("pitches",MODE_PRIVATE).edit().putString(key,fields.joinToString(",")).apply()
    storeDetails(data); refreshPitches(); selectSavedPitch(key); dialog.dismiss()
   }
  }; dialog.show()
 }

 private lateinit var ballStatus: TextView
 private lateinit var connectionButton: Button
 private lateinit var focusPanel: LinearLayout
 private lateinit var historyPanel: LinearLayout
 private lateinit var settingsPanel: LinearLayout
 private lateinit var spinView: SpinView
 private var ballReady = false
 private val ink = Color.rgb(20, 32, 47)
 private val muted = Color.rgb(113, 128, 145)
 private val accent = Color.rgb(238, 166, 37)
 private fun dp(n: Int) = (n * resources.displayMetrics.density).toInt()
 private fun label(value: String, size: Float = 14f, color: Int = ink) = TextView(this).apply {
  text = value; textSize = size; setTextColor(color); setPadding(0, dp(6), 0, dp(6))
 }
 private fun card() = LinearLayout(this).apply {
  orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(14), dp(18), dp(14))
  background = GradientDrawable().apply { setColor(Color.WHITE); cornerRadius = dp(16).toFloat() }
  layoutParams = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(12) }
 }
 private fun action(title: String, click: () -> Unit) = Button(this).apply {
  text = title; isAllCaps = false; setTextColor(ink); setOnClickListener { click() }
 }
 private lateinit var status: TextView
 private lateinit var log: TextView
 private lateinit var devices: LinearLayout
 private lateinit var speed: EditText
 private lateinit var spin: EditText
 private lateinit var pitchType: Spinner
 private lateinit var pitchList: LinearLayout
 private lateinit var pitchCount: TextView
 private val handler = Handler(Looper.getMainLooper())
 private val adapter by lazy { (getSystemService(BLUETOOTH_SERVICE) as BluetoothManager).adapter }
 private val seen = mutableSetOf<String>()
 private val pendingDescriptors: ArrayDeque<BluetoothGattDescriptor> = ArrayDeque()
 private var gatt: BluetoothGatt? = null
 private var scanning = false
 private val connectionTimeout = Runnable {
  if (gatt != null && !ballReady) { disconnectBall(); show("Connection timed out. Close other ball apps, wake the ball, and tap Connect.") }
 }
 private fun updateConnectionUi(message: String) {
  ballStatus.text = message
  connectionButton.text = when { scanning -> "Cancel search"; gatt != null -> "Disconnect"; else -> "Connect ball" }
 }
 private fun connectionAction() {
  if (scanning || gatt != null) disconnectBall() else startScan()
 }
 private fun disconnectBall() {
  stopScan()
  handler.removeCallbacks(connectionTimeout)
  val old = gatt; gatt = null; ballReady = false
  pendingDescriptors.clear(); pendingPitches.clear(); savedEvents.clear()
  if (old != null) {
   try { if (connectAllowed()) old.disconnect() } catch (_: SecurityException) {}
   old.close()
  }
  devices.removeAllViews()
  updateConnectionUi("● Disconnected")
  show("Ball disconnected. Tap Connect ball when ready.")
 }
 private val scanTimeout = Runnable {
  if (scanning) {
   stopScan()
   updateConnectionUi("● Ball not found")
   show("Ball not found. Wake it, keep it near your phone, close other ball apps, and tap Connect again.")
  }
 }
 private data class PendingPitch(var speedMph: Double? = null, var spinRpm: Int? = null, var updatedAt: Long = 0)
 private val pendingPitches = mutableMapOf<Int, PendingPitch>()
 private val savedEvents = mutableMapOf<Int, Long>()
 private val pitchLogicDataUuid = UUID.fromString("4b810002-0394-7ff1-f00b-ab59cb8a9de3")
 private val scanCallback = object : ScanCallback() {
  override fun onScanResult(callbackType: Int, result: ScanResult) {
   val device = result.device
   val name = result.scanRecord?.deviceName ?: if (connectAllowed()) device.name else null
   runOnUiThread {
    if (!scanning) return@runOnUiThread
    val service = android.os.ParcelUuid(UUID.fromString("4b810001-0394-7ff1-f00b-ab59cb8a9de3"))
    val preferred = getSharedPreferences("connection", MODE_PRIVATE).getString("ball_address", "CA:EE:EF:26:BF:75")
    if (!(device.address == preferred || name?.contains("pitchlogic", true) == true || result.scanRecord?.serviceUuids?.contains(service) == true)) return@runOnUiThread
    if (!seen.add(device.address)) return@runOnUiThread
    show("Found PitchLogic ball; connecting automatically")
    stopScan(); connect(device)
   }
  }
  override fun onBatchScanResults(results: MutableList<ScanResult>) {
   results.forEach { onScanResult(ScanSettings.CALLBACK_TYPE_ALL_MATCHES, it) }
  }
  override fun onScanFailed(errorCode: Int) {
   runOnUiThread { stopScan(); updateConnectionUi("● Search failed"); show("Scan failed: $errorCode. Wait briefly before retrying.") }
  }
 }
 private val callback = object : BluetoothGattCallback() {
  override fun onConnectionStateChange(g: BluetoothGatt, statusCode: Int, state: Int) {
   runOnUiThread {
    if (gatt !== g) return@runOnUiThread
    if (statusCode == BluetoothGatt.GATT_SUCCESS && state == BluetoothProfile.STATE_CONNECTED) {
     show("Connected; checking ball")
     updateConnectionUi("● Preparing ball…")
     if (connectAllowed() && !g.requestMtu(247)) g.discoverServices()
    } else if (state == BluetoothProfile.STATE_DISCONNECTED || statusCode != BluetoothGatt.GATT_SUCCESS) {
     disconnectBall(); show("Connection ended ($statusCode). Tap Connect ball to retry.")
    }
   }
  }
  override fun onMtuChanged(g: BluetoothGatt, mtu: Int, statusCode: Int) {
   runOnUiThread {
    if (gatt !== g) return@runOnUiThread
    show("Bluetooth packet size: $mtu")
    if (connectAllowed()) g.discoverServices()
   }
  }
  override fun onServicesDiscovered(g: BluetoothGatt, statusCode: Int) {
   runOnUiThread {
    if (gatt !== g) return@runOnUiThread
    if (statusCode != BluetoothGatt.GATT_SUCCESS) { disconnectBall(); show("Could not prepare ball. Tap Connect to retry."); return@runOnUiThread }
    val c = g.getService(UUID.fromString("4b810001-0394-7ff1-f00b-ab59cb8a9de3"))?.getCharacteristic(pitchLogicDataUuid)
    if (c == null || c.properties and BluetoothGattCharacteristic.PROPERTY_NOTIFY == 0) { disconnectBall(); show("This device is not a compatible PitchLogic ball"); return@runOnUiThread }
    val descriptor = c.getDescriptor(UUID.fromString("00002902-0000-1000-8000-00805f9b34fb"))
    if (descriptor == null || !connectAllowed() || !g.setCharacteristicNotification(c, true)) { disconnectBall(); show("Could not enable ball data. Tap Connect to retry."); return@runOnUiThread }
    pendingDescriptors.clear(); pendingDescriptors.add(descriptor)
    val battery = g.getService(UUID.fromString("0000180f-0000-1000-8000-00805f9b34fb"))?.getCharacteristic(UUID.fromString("00002a19-0000-1000-8000-00805f9b34fb"))
    if (battery != null && g.setCharacteristicNotification(battery, true)) battery.getDescriptor(UUID.fromString("00002902-0000-1000-8000-00805f9b34fb"))?.let { pendingDescriptors.add(it) }
    writeNextDescriptor(g)
   }
  }
  override fun onDescriptorWrite(g: BluetoothGatt, d: BluetoothGattDescriptor, statusCode: Int) {
   runOnUiThread {
    if (gatt !== g) return@runOnUiThread
    show("Subscribed ${d.characteristic.uuid}: $statusCode")
    if (d.characteristic.uuid == pitchLogicDataUuid) {
     if (statusCode != BluetoothGatt.GATT_SUCCESS) { disconnectBall(); show("Ball data could not start. Tap Connect to retry."); return@runOnUiThread }
     ballReady = true; handler.removeCallbacks(connectionTimeout)
     getSharedPreferences("connection", MODE_PRIVATE).edit().putString("ball_address", g.device.address).apply()
     updateConnectionUi("● Ball connected"); show("Ball connected. Live metrics are awaiting verification; manual pitch entry is available in Settings.")
    }
    writeNextDescriptor(g)
   }
  }
  override fun onCharacteristicChanged(g: BluetoothGatt, c: BluetoothGattCharacteristic, value: ByteArray) {
   val bytes = value.clone()
   runOnUiThread { if (gatt === g) packet(c.uuid, bytes) }
  }
  @Deprecated("Android 13 compatibility") override fun onCharacteristicChanged(g: BluetoothGatt, c: BluetoothGattCharacteristic) {
   @Suppress("DEPRECATION") val bytes = c.value?.clone() ?: byteArrayOf()
   runOnUiThread { if (gatt === g) packet(c.uuid, bytes) }
  }
 }
 private fun writeNextDescriptor(g: BluetoothGatt) {
  if (!connectAllowed()) return
  val d = pendingDescriptors.poll() ?: return
  val indication = d.characteristic.properties and BluetoothGattCharacteristic.PROPERTY_NOTIFY == 0
  val value = if (indication) BluetoothGattDescriptor.ENABLE_INDICATION_VALUE else BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE
  if (Build.VERSION.SDK_INT >= 33) {
   val code = g.writeDescriptor(d, value)
   if (code != BluetoothStatusCodes.SUCCESS) {
    if (d.characteristic.uuid == pitchLogicDataUuid) { disconnectBall(); show("Could not start ball data ($code). Tap Connect to retry.") }
    else writeNextDescriptor(g)
   }
  } else if (!writeLegacyDescriptor(g, d, value)) {
   if (d.characteristic.uuid == pitchLogicDataUuid) { disconnectBall(); show("Could not start ball data. Tap Connect to retry.") }
   else writeNextDescriptor(g)
  }
 }
 @Suppress("DEPRECATION") private fun writeLegacyDescriptor(g: BluetoothGatt, d: BluetoothGattDescriptor, value: ByteArray): Boolean {
  d.value = value
  return g.writeDescriptor(d)
 }
 private fun packet(uuid: UUID, value: ByteArray) {
  if (Looper.myLooper() != Looper.getMainLooper()) {
   val copy = value.clone()
   handler.post { packet(uuid, copy) }
   return
  }
  show("Notify $uuid: ${value.joinToString("") { "%02X".format(it.toInt() and 255) }}")
  if (uuid == UUID.fromString("00002a19-0000-1000-8000-00805f9b34fb") && value.isNotEmpty()) ballStatus.text = "● Connected · ${u8(value[0])}%"
  if (uuid == pitchLogicDataUuid) decodePitchLogic(value)
 }
 private fun u8(value: Byte) = value.toInt() and 0xff
 private fun leFloat(value: ByteArray, offset: Int): Float? {
  if (offset < 0 || offset + 4 > value.size) return null
  return ByteBuffer.wrap(value, offset, 4).order(ByteOrder.LITTLE_ENDIAN).float.takeIf { it.isFinite() }
 }
 private fun decodePitchLogic(value: ByteArray) {
  // Packet layouts remain unverified. Do not reinterpret timestamps or arbitrary
  // float fields as pitch measurements. Retain raw bytes in the connection trace.
  if (value.size < 4) return
  if (u8(value[0]) in setOf(0x9a,0x9e) && u8(value[1]) in setOf(0x1a,0x1b,0x1c)) {
   show("Pitch summary received; live metric decoding is awaiting verification")
  }
 }
 private fun permission(permission: String) = checkSelfPermission(permission) == PackageManager.PERMISSION_GRANTED
 private fun connectAllowed() = Build.VERSION.SDK_INT < 31 || permission(Manifest.permission.BLUETOOTH_CONNECT)
 private fun show(message: String) {
  runOnUiThread {
   if (!message.startsWith("Notify ") && !message.startsWith("Service ") && !message.startsWith("Characteristic ") && !message.startsWith("Subscribed ")) status.text = message
   val line = "${SimpleDateFormat("HH:mm:ss.SSS", Locale.US).format(Date())} $message\n"
   log.append(line)
   openFileOutput("ble_trace.txt", MODE_APPEND).use { it.write(line.toByteArray()) }
  }
 }
 override fun onCreate(savedInstanceState: Bundle?) {
  super.onCreate(savedInstanceState)
  window.statusBarColor = ink; window.navigationBarColor = ink
  val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.rgb(240,243,247)) }
  root.setOnApplyWindowInsetsListener { view, insets ->
   if (Build.VERSION.SDK_INT >= 30) {
    val bars = insets.getInsets(android.view.WindowInsets.Type.systemBars())
    view.setPadding(bars.left, bars.top, bars.right, bars.bottom)
   } else {
    @Suppress("DEPRECATION")
    view.setPadding(insets.systemWindowInsetLeft,insets.systemWindowInsetTop,insets.systemWindowInsetRight,insets.systemWindowInsetBottom)
   }
   insets
  }
  val header = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(dp(18),dp(12),dp(18),dp(12)); setBackgroundColor(ink) }
  header.addView(label("PITCHLAB", 21f, Color.WHITE), LinearLayout.LayoutParams(0,-2,1f))
  ballStatus = label("● Connect ball", 13f, accent).apply { setOnClickListener { if (gatt == null && !scanning) startScan() } }; header.addView(ballStatus); root.addView(header)
  val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16),dp(16),dp(16),dp(16)) }
  root.addView(ScrollView(this).apply { addView(content) }, LinearLayout.LayoutParams(-1,0,1f))
  focusPanel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }; content.addView(focusPanel)
  focusPanel.addView(label("BULLPEN  /  LIVE PITCH", 12f, muted))
  connectionButton = action("Connect ball") { connectionAction() }; focusPanel.addView(connectionButton)
  val top = card(); focusPanel.addView(top)
  latestLabel = label("Ready for your first pitch",18f); top.addView(latestLabel)
  top.addView(label("Select pitch type",12f,muted))
  pitchType = Spinner(this).apply { adapter = ArrayAdapter(this@MainActivity,android.R.layout.simple_spinner_dropdown_item,listOf("Fastball","Four seam","Two seam","Sinker","Cutter","Slider","Curveball","Changeup","Splitter","Other")) }; top.addView(pitchType)
  val metrics = LinearLayout(this); top.addView(metrics)
  fun metric(title: String, unit: String): TextView {
   val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }; metrics.addView(box,LinearLayout.LayoutParams(0,-2,1f))
   box.addView(label(title,12f,muted)); val number = label("—",44f); box.addView(number); box.addView(label(unit,12f,muted)); return number
  }
  latestSpeed = metric("VELOCITY","mph"); latestSpin = metric("SPIN RATE","rpm")
  val visual = card(); focusPanel.addView(visual); visual.addView(label("Spin & release",18f))
  spinView = SpinView(this); visual.addView(spinView,LinearLayout.LayoutParams(-1,dp(195)))
  visual.addView(label("Drag to rotate the ball. Pinch to zoom. Touch points are annotations.",12f,muted))
  val touchActions=LinearLayout(this)
  touchActions.addView(action("Mark last touch") { markingTouch=!markingTouch; Toast.makeText(this,if(markingTouch) "Tap the ball to add touch points" else "Rotate mode",Toast.LENGTH_SHORT).show(); spinView.invalidate() },LinearLayout.LayoutParams(0,-2,1f))
  touchActions.addView(action("Clear points") { if(selectedPitchKey != null) { val d=pitchDetails(selectedPitchKey); d.remove("touch_points"); storeDetails(d) } },LinearLayout.LayoutParams(0,-2,1f)); visual.addView(touchActions)
  val details=card(); focusPanel.addView(details); details.addView(label("Pitch metrics",18f))
  var metricIndex=0
  var metricRow=LinearLayout(this)
  fun reading(title: String): TextView {
   if(metricIndex%2==0) { metricRow=LinearLayout(this); details.addView(metricRow) }
   val cell=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(0,0,dp(8),dp(8)) }; metricRow.addView(cell,LinearLayout.LayoutParams(0,-2,1f)); cell.addView(label(title,11f,muted)); val number=label("—",22f); cell.addView(number); metricIndex++; return number
  }
  axisReading=reading("SPIN AXIS"); directionReading=reading("SPIN DIRECTION"); horizontalReading=reading("HORIZONTAL MOVEMENT"); verticalReading=reading("VERTICAL MOVEMENT")
  detailSource=label("Awaiting verified sensor metrics",12f,muted); details.addView(detailSource)
  details.addView(action("Edit pitch label & comparison values") { editPitchDetails() })
  details.addView(action("Share this pitch's details") {
   val key=selectedPitchKey
   if(key == null) Toast.makeText(this,"Save a pitch first",Toast.LENGTH_SHORT).show()
   else {
    val payload=JSONObject().put("timestamp",key).put("pitch",getSharedPreferences("pitches",MODE_PRIVATE).getString(key,""))
     .put("comparison_values",pitchDetails(key)).put("comparison_source","manual; touch points are user annotations")
    share("PitchLab pitch details",payload.toString(2))
   }
  })
  focusPanel.addView(action("View latest pitch replay") { selectedPitchKey?.let { startActivity(Intent(this,ReplayActivity::class.java).putExtra("pitch_key",it)) } ?: Toast.makeText(this,"No saved pitches yet",Toast.LENGTH_SHORT).show() })
  status = label("Connect your ball to begin",13f,muted); focusPanel.addView(status)
  devices = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }; focusPanel.addView(devices)
  historyPanel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; visibility = View.GONE }; content.addView(historyPanel)
  historyPanel.addView(label("Pitch history",26f)); pitchCount = label("",13f,muted); historyPanel.addView(pitchCount)
  pitchList = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }; historyPanel.addView(pitchList); historyPanel.addView(action("Export pitches") { shareCsv() })
  settingsPanel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; visibility = View.GONE }; content.addView(settingsPanel)
  settingsPanel.addView(label("Settings",26f)); settingsPanel.addView(action("Ball connection") { selectPage(0) })
  val manual = card(); settingsPanel.addView(manual); manual.addView(label("Manual pitch entry",18f))
  speed = EditText(this).apply { hint = "Speed (mph)"; inputType = 8194 }; spin = EditText(this).apply { hint = "Spin (rpm)"; inputType = 2 }; manual.addView(speed); manual.addView(spin); manual.addView(action("Save manual pitch") { savePitch() })
  val diagnostics = card(); settingsPanel.addView(diagnostics); diagnostics.addView(label("Connection diagnostics",18f)); diagnostics.addView(action("Share connection trace") { shareTrace() })
  log = label("Ready to connect",11f,muted).apply { maxLines = 12; setTextIsSelectable(true) }; diagnostics.addView(log)
  val nav = LinearLayout(this).apply { setPadding(dp(8),dp(4),dp(8),dp(8)); setBackgroundColor(Color.WHITE) }
  listOf("◎ Focus","≡ History","⚙ Settings").forEachIndexed { index, title -> nav.addView(action(title) { selectPage(index) },LinearLayout.LayoutParams(0,-2,1f)) }; root.addView(nav)
  setContentView(root); refreshPitches()
 }
 private fun selectPage(index: Int) {
  listOf(focusPanel,historyPanel,settingsPanel).forEachIndexed { i,p -> p.visibility = if(i == index) View.VISIBLE else View.GONE }
 }
 private inner class SpinView(context: android.content.Context) : View(context) {
  private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
  private var yaw=0.0; private var tilt=0.0; private var zoom=1f
  private var downX=0f; private var downY=0f; private var lastX=0f; private var lastY=0f; private var dragged=false
  private val scale=android.view.ScaleGestureDetector(context,object: android.view.ScaleGestureDetector.SimpleOnScaleGestureListener() {
   override fun onScale(detector: android.view.ScaleGestureDetector): Boolean { zoom=(zoom*detector.scaleFactor).coerceIn(.7f,1.5f); dragged=true; invalidate(); return true }
  })
  private fun project(x: Double,y: Double,z: Double): DoubleArray {
   val x1=x*kotlin.math.cos(yaw)+z*kotlin.math.sin(yaw)
   val z1=-x*kotlin.math.sin(yaw)+z*kotlin.math.cos(yaw)
   return doubleArrayOf(x1,y*kotlin.math.cos(tilt)-z1*kotlin.math.sin(tilt),y*kotlin.math.sin(tilt)+z1*kotlin.math.cos(tilt))
  }
  override fun onDraw(canvas: Canvas) {
   val cx=width/2f; val cy=height/2f; val r=height*.31f*zoom
   paint.color=Color.rgb(225,232,239); paint.style=Paint.Style.STROKE; paint.strokeWidth=dp(1).toFloat(); canvas.drawCircle(cx,cy,r*1.25f,paint)
   for(i in 0..11) { val a=i*Math.PI/6; canvas.drawLine(cx+(kotlin.math.cos(a)*r*1.13).toFloat(),cy+(kotlin.math.sin(a)*r*1.13).toFloat(),cx+(kotlin.math.cos(a)*r*1.25).toFloat(),cy+(kotlin.math.sin(a)*r*1.25).toFloat(),paint) }
   paint.style=Paint.Style.FILL
   paint.shader=android.graphics.RadialGradient(cx-r*.3f,cy-r*.35f,r*1.5f,intArrayOf(Color.WHITE,Color.rgb(239,238,230),Color.rgb(150,163,173)),null,android.graphics.Shader.TileMode.CLAMP)
   canvas.drawCircle(cx,cy,r,paint); paint.shader=null
   paint.style=Paint.Style.STROKE; paint.strokeWidth=dp(2).toFloat(); paint.color=Color.rgb(194,65,62)
   for(side in listOf(-1,1)) {
    var previous: DoubleArray?=null
    for(i in 0..100) {
     val a=i*Math.PI*2/100; val x=side*.48; val ring=kotlin.math.sqrt(1-x*x)
     val q=project(x,ring*kotlin.math.sin(a),ring*kotlin.math.cos(a))
     val old=previous
     if(q[2]>=0 && old != null && old[2]>=0) canvas.drawLine(cx+(old[0]*r).toFloat(),cy+(old[1]*r).toFloat(),cx+(q[0]*r).toFloat(),cy+(q[1]*r).toFloat(),paint)
     if(i%5==0 && q[2]>=0) canvas.drawLine(cx+(q[0]*r).toFloat()-dp(3),cy+(q[1]*r).toFloat()-dp(2),cx+(q[0]*r).toFloat()+dp(3),cy+(q[1]*r).toFloat()+dp(2),paint)
     previous=q
    }
   }
   val data=pitchDetails(selectedPitchKey)
   if(data.has("direction")) {
    val clock=data.getString("direction").split(":")
    val direction=(clock[0].toInt()%12+clock[1].toInt()/60.0)*Math.PI/6-Math.PI/2
    val dx=(kotlin.math.cos(direction)*r*1.22).toFloat(); val dy=(kotlin.math.sin(direction)*r*1.22).toFloat()
    paint.color=accent; paint.strokeWidth=dp(4).toFloat(); canvas.drawLine(cx+dx*.7f,cy+dy*.7f,cx+dx,cy+dy,paint)
    canvas.drawLine(cx+dx,cy+dy,cx+dx+(kotlin.math.cos(direction+2.6)*dp(9)).toFloat(),cy+dy+(kotlin.math.sin(direction+2.6)*dp(9)).toFloat(),paint)
    canvas.drawLine(cx+dx,cy+dy,cx+dx+(kotlin.math.cos(direction-2.6)*dp(9)).toFloat(),cy+dy+(kotlin.math.sin(direction-2.6)*dp(9)).toFloat(),paint)
   }
   if(data.has("axis")) {
    val angle=Math.toRadians(data.getDouble("axis")-90); val dx=(kotlin.math.cos(angle)*r*1.4).toFloat(); val dy=(kotlin.math.sin(angle)*r*1.4).toFloat()
    paint.color=Color.rgb(40,145,171); paint.strokeWidth=dp(3).toFloat(); canvas.drawLine(cx-dx,cy-dy,cx+dx,cy+dy,paint)
    val a1=angle+2.6; val a2=angle-2.6
    canvas.drawLine(cx+dx,cy+dy,cx+dx+(kotlin.math.cos(a1)*dp(10)).toFloat(),cy+dy+(kotlin.math.sin(a1)*dp(10)).toFloat(),paint)
    canvas.drawLine(cx+dx,cy+dy,cx+dx+(kotlin.math.cos(a2)*dp(10)).toFloat(),cy+dy+(kotlin.math.sin(a2)*dp(10)).toFloat(),paint)
   }
   paint.style=Paint.Style.FILL
   for(i in 0 until touchPoints.length()) {
    val point=touchPoints.getJSONArray(i); val q=project(point.getDouble(0),point.getDouble(1),point.getDouble(2))
    if(q[2]<0) continue
    val px=cx+(q[0]*r).toFloat(); val py=cy+(q[1]*r).toFloat()
    paint.color=accent; canvas.drawCircle(px,py,dp(7).toFloat(),paint)
    paint.color=ink; paint.textSize=dp(9).toFloat(); paint.textAlign=Paint.Align.CENTER; canvas.drawText("${i+1}",px,py+dp(3),paint)
   }
   paint.color=muted; paint.textSize=dp(10).toFloat(); paint.textAlign=Paint.Align.CENTER
   canvas.drawText(if(markingTouch) "TAP TO MARK LAST TOUCH · USER ANNOTATION" else "ROTATE & ZOOM · ILLUSTRATIVE SEAMS",cx,height-dp(5).toFloat(),paint)
   if(data.has("direction")) { paint.color=ink; canvas.drawText("Spin direction ${data.getString("direction")} · manual",cx,dp(14).toFloat(),paint) }
  }
  override fun onTouchEvent(event: MotionEvent): Boolean {
   scale.onTouchEvent(event)
   when(event.actionMasked) {
    MotionEvent.ACTION_DOWN -> { downX=event.x; downY=event.y; lastX=event.x; lastY=event.y; dragged=false; parent.requestDisallowInterceptTouchEvent(true) }
    MotionEvent.ACTION_MOVE -> {
     if(kotlin.math.abs(event.x-downX)+kotlin.math.abs(event.y-downY)>dp(8)) dragged=true
     if(!scale.isInProgress && event.pointerCount==1) { yaw+=(event.x-lastX)/130.0; tilt=((tilt+(event.y-lastY)/130.0)).coerceIn(-1.4,1.4); invalidate() }
     lastX=event.x; lastY=event.y
    }
    MotionEvent.ACTION_UP -> {
     parent.requestDisallowInterceptTouchEvent(false)
     if(markingTouch && !dragged) {
      if(selectedPitchKey==null) { Toast.makeText(context,"Save a pitch first",Toast.LENGTH_SHORT).show(); return true }
      val r=height*.31f*zoom; val x=(event.x-width/2f)/r.toDouble(); val y=(event.y-height/2f)/r.toDouble()
      if(x*x+y*y<=1 && touchPoints.length()<5) {
       val z=kotlin.math.sqrt(1-x*x-y*y); val y1=y*kotlin.math.cos(tilt)+z*kotlin.math.sin(tilt); val z1=-y*kotlin.math.sin(tilt)+z*kotlin.math.cos(tilt)
       val point=JSONArray().put(x*kotlin.math.cos(yaw)-z1*kotlin.math.sin(yaw)).put(y1).put(x*kotlin.math.sin(yaw)+z1*kotlin.math.cos(yaw))
       val d=pitchDetails(selectedPitchKey); val points=d.optJSONArray("touch_points") ?: JSONArray(); points.put(point); d.put("touch_points",points); storeDetails(d)
      }
     }
     performClick()
    }
    MotionEvent.ACTION_CANCEL -> parent.requestDisallowInterceptTouchEvent(false)
   }; return true
  }
  override fun performClick(): Boolean { super.performClick(); return true }
 }
 private fun startScan() {
  if (gatt != null || scanning) return
  val required = if (Build.VERSION.SDK_INT >= 31) arrayOf(Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT) else arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)
  val missing = required.filterNot(::permission)
  if (missing.isNotEmpty()) { requestPermissions(missing.toTypedArray(), 1); return }
  if (adapter == null) { show("Bluetooth is not available on this device"); return }
  if (adapter?.isEnabled != true) { startActivityForResult(Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE), 2); return }
  stopScan(); devices.removeAllViews(); seen.clear()
  val scanner = adapter?.bluetoothLeScanner
  if (scanner == null) { show("Bluetooth scanner unavailable. Toggle Bluetooth and retry."); return }
  val settings = ScanSettings.Builder().setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY).build()
  try {
   scanning = true
   scanner.startScan(null, settings, scanCallback)
   updateConnectionUi("● Finding your ball…")
   show("Finding your ball. Keep it awake and near your phone.")
   handler.postDelayed(scanTimeout, 12000)
  } catch (e: SecurityException) {
   scanning = false; updateConnectionUi("● Disconnected"); show("Android blocked Bluetooth scan. Allow Nearby devices in PitchLab settings.")
  } catch (e: IllegalStateException) {
   scanning = false; updateConnectionUi("● Disconnected"); show("Bluetooth unavailable. Enable Bluetooth and retry.")
  }
 }
 private fun stopScan() {
  handler.removeCallbacks(scanTimeout)
  val wasScanning = scanning
  scanning = false
  if (wasScanning && (Build.VERSION.SDK_INT < 31 || permission(Manifest.permission.BLUETOOTH_SCAN))) {
   try { adapter?.bluetoothLeScanner?.stopScan(scanCallback) } catch (_: SecurityException) {} catch (_: IllegalStateException) {}
  }
 }
 private fun connect(device: BluetoothDevice) {
  if (!connectAllowed() || gatt != null) return
  stopScan(); pendingDescriptors.clear(); pendingPitches.clear(); savedEvents.clear()
  show("Connecting to your PitchLogic ball…")
  try {
   gatt = device.connectGatt(this, false, callback, BluetoothDevice.TRANSPORT_LE)
   if (gatt == null) { updateConnectionUi("● Disconnected"); show("Could not connect. Tap Connect to retry."); return }
   updateConnectionUi("● Connecting…")
   handler.postDelayed(connectionTimeout, 20000)
  } catch (_: SecurityException) { disconnectBall(); show("Allow Nearby devices permission, then tap Connect.") }
 }
 override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
  super.onActivityResult(requestCode, resultCode, data)
  if (requestCode == 2) {
   if (resultCode == RESULT_OK) startScan() else show("Turn on Bluetooth to connect the ball.")
  }
 }
 private fun savePitch() {
  val mph = speed.text.toString().toDoubleOrNull(); val rpm = spin.text.toString().toIntOrNull()
  if (mph == null || rpm == null || mph !in 1.0..130.0 || rpm !in 0..6000) { show("Enter speed 1–130 mph and spin 0–6000 rpm"); return }
  savePitchRecord(pitchType.selectedItem.toString(), mph, rpm, "manual", null)
  speed.text.clear(); spin.text.clear()
 }
 private fun savePitchRecord(type: String, mph: Double, rpm: Int, source: String, event: Int?) {
  val time = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS", Locale.US).format(Date())
  getSharedPreferences("pitches", MODE_PRIVATE).edit()
   .putString(time, "$type,${"%.2f".format(Locale.US, mph)},$rpm,$source,${event ?: ""}").apply()
  show(if (source == "pitchlogic") "Auto-saved pitch ${event ?: ""}: ${"%.2f".format(Locale.US, mph)} mph • $rpm rpm" else "Saved $type: ${"%.2f".format(Locale.US, mph)} mph • $rpm rpm")
  refreshPitches()
 }
 private fun entries() = getSharedPreferences("pitches", MODE_PRIVATE).all.entries.sortedBy { it.key }
 private fun refreshPitches() {
  val items = entries().asReversed()
  val latest = items.firstOrNull()
  selectedPitchKey = latest?.key
  if (latest != null) {
   val f = latest.value.toString().split(",")
   latestSpeed.text = f.getOrNull(1) ?: "—"; latestSpin.text = f.getOrNull(2) ?: "—"
   latestLabel.text = "${f.firstOrNull() ?: "Pitch"} · Your pitch tag"
  }
  refreshDetails()
  pitchCount.text = "RECENT PITCHES  •  ${items.size}"
  pitchList.removeAllViews()
  if (items.isEmpty()) {
   pitchList.addView(TextView(this).apply { text = "Save a pitch to see it here. Tap a pitch to open its replay."; setTextColor(android.graphics.Color.LTGRAY); setPadding(8, 12, 8, 20) })
  }
  items.take(20).forEach { entry ->
   val fields = entry.value.toString().split(",")
   val heading = "${fields.getOrNull(0) ?: "Pitch"}   ${fields.getOrNull(1) ?: "—"} mph   ${fields.getOrNull(2) ?: "—"} rpm"
   pitchList.addView(Button(this).apply {
    text = "$heading\n${entry.key.replace('T', ' ')}  •  VIEW PITCH"
    isAllCaps = false
    setOnClickListener { selectSavedPitch(entry.key); selectPage(0) }
   })
  }
 }
 private fun selectSavedPitch(key: String) {
  val record=getSharedPreferences("pitches",MODE_PRIVATE).getString(key,null) ?: return
  selectedPitchKey=key
  val f=record.split(",")
  latestSpeed.text=f.getOrNull(1) ?: "—"; latestSpin.text=f.getOrNull(2) ?: "—"
  latestLabel.text="${f.firstOrNull() ?: "Pitch"} · Your pitch tag"
  markingTouch=false; refreshDetails()
 }
 private fun shareCsv() {
  val csv = "timestamp,pitch_type,speed_mph,spin_rpm,source,event_id\n" + entries().joinToString("\n") { entry ->
   val fields = entry.value.toString().split(",")
   "${entry.key},${fields.getOrElse(0) { "Pitch" }},${fields.getOrElse(1) { "" }},${fields.getOrElse(2) { "" }},${fields.getOrElse(3) { "manual" }},${fields.getOrElse(4) { "" }}"
  }
  share("PitchLab pitches", csv)
 }
 private fun shareTrace() {
  val trace = try { openFileInput("ble_trace.txt").bufferedReader().use { it.readText() } } catch (_: Exception) { "No diagnostic data yet." }
  share("PitchLab Bluetooth trace", trace)
 }
 private fun share(title: String, body: String) {
  val intent = Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_SUBJECT, title); putExtra(Intent.EXTRA_TEXT, body) }
  startActivity(Intent.createChooser(intent, "Share $title"))
 }
 override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
  super.onRequestPermissionsResult(requestCode, permissions, grantResults)
  if (requestCode == 1 && grantResults.isNotEmpty() && grantResults.all { it == PackageManager.PERMISSION_GRANTED }) startScan()
  else show("Bluetooth permission required for scanning")
 }
 override fun onDestroy() { disconnectBall(); super.onDestroy() }
}
