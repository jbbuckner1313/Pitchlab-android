package com.example.pitchlab

import android.app.Activity
import android.graphics.*
import android.os.Bundle
import android.os.SystemClock
import android.view.MotionEvent
import android.view.View
import android.widget.*
import java.util.Locale
import kotlin.math.max

/** Illustrative replay. Never interprets spin or speed as measured ball movement. */
class ReplayActivity : Activity() {
 private lateinit var field: ReplayView
 private lateinit var play: Button
 private lateinit var progress: SeekBar
 private var playing = true
 private var fraction = 0f
 private var lastFrame = 0L
 private var speedMultiplier = 1f
 private val animation = object : Runnable {
  override fun run() {
   val now = SystemClock.uptimeMillis()
   if (playing) {
    if (lastFrame != 0L) fraction = (fraction + (now - lastFrame) * speedMultiplier / 1800f).coerceAtMost(1f)
    if (fraction >= 1f) { playing = false; play.text = "Replay" }
    progress.progress = (fraction * 1000).toInt()
    field.invalidate()
   }
   lastFrame = now
   field.postDelayed(this, 16)
  }
 }
 override fun onCreate(savedInstanceState: Bundle?) {
  super.onCreate(savedInstanceState)
  val saved = getSharedPreferences("pitches", MODE_PRIVATE).all
  val selected = intent.getStringExtra("pitch_key")
  val row = saved.entries.firstOrNull { it.key == selected } ?: saved.entries.maxByOrNull { it.key }
  val values = row?.value?.toString()?.split(",") ?: emptyList()
  val type = values.getOrNull(0) ?: "No pitch saved"
  val mph = values.getOrNull(1)?.toFloatOrNull()
  val rpm = values.getOrNull(2)?.toIntOrNull()
  val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.rgb(8, 18, 30)) }
  root.addView(TextView(this).apply { text = "PITCHLAB  /  VIRTUAL REPLAY"; textColor = Color.rgb(100,231,255); textSize = 18f; setPadding(24, 24, 12, 12) })
  field = ReplayView(type, mph, rpm)
  root.addView(field, LinearLayout.LayoutParams(-1, 0, 1f))
  progress = SeekBar(this).apply { max = 1000; setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
   override fun onProgressChanged(bar: SeekBar, value: Int, fromUser: Boolean) { if (fromUser) { fraction = value / 1000f; field.invalidate() } }
   override fun onStartTrackingTouch(bar: SeekBar) { playing = false; play.text = "Play" }
   override fun onStopTrackingTouch(bar: SeekBar) {}
  }) }; root.addView(progress)
  val controls = LinearLayout(this)
  play = Button(this).apply { text = "Pause"; setOnClickListener { if (fraction >= 1f) fraction = 0f; playing = !playing; text = if (playing) "Pause" else "Play" } }
  controls.addView(play, LinearLayout.LayoutParams(0, -2, 1f))
  controls.addView(Button(this).apply { text = "Restart"; setOnClickListener { fraction = 0f; playing = true; play.text = "Pause"; field.invalidate() } }, LinearLayout.LayoutParams(0, -2, 1f))
  controls.addView(Button(this).apply { text = "${speedMultiplier}×"; setOnClickListener { speedMultiplier = if (speedMultiplier == 1f) 0.5f else if (speedMultiplier == 0.5f) 2f else 1f; text = "${speedMultiplier}×" } }, LinearLayout.LayoutParams(0, -2, 1f))
  root.addView(controls)
  root.addView(TextView(this).apply { text = "Movement  —     Release point  —     Spin axis  —\nIllustrative flight • measured values appear above when available"; textColor = Color.LTGRAY; textSize = 12f; setPadding(20, 8, 20, 24) })
  setContentView(root)
  field.post(animation)
 }
 override fun onDestroy() { field.removeCallbacks(animation); super.onDestroy() }
 inner class ReplayView(private val pitchType: String, private val mph: Float?, private val rpm: Int?) : View(this@ReplayActivity) {
  private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
  private val ball = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; setShadowLayer(18f, 0f, 2f, Color.WHITE) }
  private fun line(x1: Float,y1: Float,x2: Float,y2: Float,color: Int,width: Float = 2f) {
   paint.color = color; paint.strokeWidth = width; paint.style = Paint.Style.STROKE; canvasRef?.drawLine(x1,y1,x2,y2,paint); paint.style = Paint.Style.FILL
  }
  private var canvasRef: Canvas? = null
  private fun label(s: String,x: Float,y: Float,size: Float,color: Int = Color.WHITE) { paint.color = color; paint.textSize = size; paint.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL); canvasRef?.drawText(s,x,y,paint) }
  override fun onDraw(canvas: Canvas) {
   super.onDraw(canvas); canvasRef = canvas
   val w = width.toFloat(); val h = height.toFloat(); val scale = w / 400f
   canvas.drawColor(Color.rgb(8,18,30))
   val horizon = h * .35f
   paint.shader = LinearGradient(0f,horizon,0f,h,Color.rgb(15,68,70),Color.rgb(9,39,48),Shader.TileMode.CLAMP)
   canvas.drawRect(0f,horizon,w,h,paint); paint.shader = null
   paint.color = Color.rgb(28,39,55); canvas.drawRect(0f,horizon-65*scale,w,horizon,paint)
   val crowd = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(64,95,106); strokeWidth = 2f }
   for (i in 0..90) { val x = ((i * 47) % 401) * scale; val y = horizon-60*scale+((i*17)%49)*scale; canvas.drawPoint(x,y,crowd) }
   paint.color = Color.argb(100,245,255,230)
   canvas.drawCircle(w*.13f,horizon-52*scale,7*scale,paint)
   canvas.drawCircle(w*.87f,horizon-52*scale,7*scale,paint)
   paint.color = Color.argb(12,220,240,255)
   canvas.drawCircle(w*.13f,horizon-52*scale,58*scale,paint)
   canvas.drawCircle(w*.87f,horizon-52*scale,58*scale,paint)
   val ground = Path().apply { moveTo(w*.49f,h*.62f); lineTo(w*.51f,h*.62f); lineTo(w*.85f,h); lineTo(w*.15f,h); close() }
   paint.color = Color.rgb(150,105,71); canvas.drawPath(ground,paint)
   val plateY = h*.66f; val moundY = h*.89f
   line(w*.5f,plateY,w*.5f,moundY,Color.argb(95,255,255,255),2f)
   paint.color = Color.WHITE
   val plate = Path().apply { moveTo(w*.485f,plateY); lineTo(w*.515f,plateY); lineTo(w*.52f,plateY+8*scale); lineTo(w*.5f,plateY+15*scale); lineTo(w*.48f,plateY+8*scale); close() }
   canvas.drawPath(plate,paint)
   paint.style = Paint.Style.STROKE; paint.strokeWidth = 2f*scale; paint.color = Color.rgb(95,230,252)
   canvas.drawRoundRect(w*.43f,plateY-83*scale,w*.57f,plateY-12*scale,4*scale,4*scale,paint)
   paint.style = Paint.Style.FILL
   label("STRIKE ZONE", w*.385f, plateY-92*scale, 12*scale,Color.rgb(95,230,252))
   val path = Path()
   val startX = w*.5f; val startY = moundY-16*scale
   val endX = w*.5f; val endY = plateY-38*scale
   path.moveTo(startX,startY)
   path.cubicTo(w*.47f,h*.72f,w*.53f,h*.55f,endX,endY)
   paint.color = Color.argb(155,92,230,255); paint.style = Paint.Style.STROKE; paint.strokeWidth = 3*scale
   val measure = PathMeasure(path,false)
   val partial = Path(); measure.getSegment(0f,measure.length * fraction,partial,true)
   canvas.drawPath(partial,paint); paint.style = Paint.Style.FILL
   val pos = FloatArray(2); measure.getPosTan(measure.length * fraction,pos,null)
   val radius = (7f + (1f-fraction)*9f)*scale
   canvas.drawCircle(pos[0],pos[1],radius,ball)
   paint.color = Color.RED; paint.strokeWidth = 1.5f*scale
   canvas.drawArc(pos[0]-radius*.65f,pos[1]-radius*.65f,pos[0]+radius*.65f,pos[1]+radius*.65f,65f,130f,false,paint)
   canvas.drawArc(pos[0]-radius*.65f,pos[1]-radius*.65f,pos[0]+radius*.65f,pos[1]+radius*.65f,245f,130f,false,paint)
   label(pitchType.uppercase(Locale.US),20*scale,40*scale,20*scale)
   label("${mph?.let { "%.1f".format(Locale.US,it) } ?: "—"} MPH",20*scale,72*scale,18*scale,Color.rgb(100,231,255))
   label("${rpm ?: "—"} RPM",20*scale,100*scale,18*scale,Color.rgb(100,231,255))
   label("${(fraction*100).toInt()}%",w-65*scale,40*scale,18*scale)
   canvasRef = null
  }
 }
}
