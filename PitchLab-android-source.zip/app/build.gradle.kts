plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android { namespace = "com.example.pitchlab"; compileSdk = 35; buildToolsVersion = "35.0.0"
 defaultConfig { applicationId = "com.example.pitchlab.focus"; minSdk = 26; targetSdk = 35; versionCode = 5; versionName = "0.5-pitch-displays" } }

android { compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 } }
