plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android { namespace = "com.example.pitchlab"; compileSdk = 35
 defaultConfig { applicationId = "com.example.pitchlab.blefix"; minSdk = 26; targetSdk = 35; versionCode = 2; versionName = "0.2-scan-fix" } }
